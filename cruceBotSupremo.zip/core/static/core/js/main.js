// JavaScript principal - Funciones globales aquí

console.log('Sistema de Reportes - OK');
