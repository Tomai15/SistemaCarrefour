# Instrucciones para el logo

1. Descarga el logo de Carrefour (formato PNG con fondo transparente)
2. Guárdalo en esta carpeta con el nombre: `carrefour-logo.png`

## Opciones para conseguir el logo:

- **Opción 1**: Busca en Google Images "carrefour logo png transparent"
- **Opción 2**: Usa este placeholder mientras tanto: https://via.placeholder.com/150x40/0055A5/FFFFFF?text=CARREFOUR

## Alternativa temporal:

Si no tienes el logo, puedes comentar la línea del <img> en `base.html` temporalmente.
